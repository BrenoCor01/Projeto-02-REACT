export default function NoPage(){
    return(
        <div>
            <h1>NoPage</h1>
        </div>
    )
}