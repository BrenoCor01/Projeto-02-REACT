export default function Blogs(){
    return(
        <div>
            <h1>Blogs</h1>
        </div>
    )
}